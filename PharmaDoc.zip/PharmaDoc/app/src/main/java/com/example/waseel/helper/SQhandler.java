package com.example.waseel.helper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.HashMap;

public class SQhandler extends SQLiteOpenHelper {

    private static final String TAG = SQLiteHandler.class.getSimpleName();

    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "logicalh_haya";

    // Login table name
    private static final String TABLE_USER = "appointment";

    // Login Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_specialization = "specialization";
    private static final String KEY_doctor = "doctor";
    private static final String KEY_location = "location";
    private static final String KEY_mobile = "mobile";
    private static final String KEY_date = "date";
    private static final String KEY_time = "time";
    private static final String KEY_email = "email";

    public SQhandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_LOGIN_TABLE = "CREATE TABLE " + TABLE_USER + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_specialization + KEY_doctor + " TEXT,"
                + KEY_email + " TEXT ," + KEY_location + KEY_time + KEY_mobile + " TEXT,"
                + KEY_date + " TEXT" + ")";
        db.execSQL(CREATE_LOGIN_TABLE);

        Log.d(TAG, "Database tables created");
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);

        // Create tables again
        onCreate(db);
    }

    /**
     * Storing user details in database
     * */
    public void addUser(String doctor, String specialization, String location, String date, String email, String id, String time, String phonenumber) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_specialization, specialization); // Name
        values.put(KEY_doctor, doctor);
        values.put(KEY_location, location);
        values.put(KEY_mobile, phonenumber);// Email
        values.put(KEY_ID, id); // Email
        values.put(KEY_date, date); // Created At
        values.put(KEY_time, time);
        values.put(KEY_email, email);
        // Inserting Row
        long idd = db.insert(TABLE_USER, null, values);
        db.close(); // Closing database connection

        Log.d(TAG, "New Appointment inserted into sqlite: " + idd);
    }

    /**
     * Getting user data from database
     * */
    public HashMap<String, String> getUserDetails() {
        HashMap<String, String> user = new HashMap<String, String>();
        String selectQuery = "SELECT  * FROM " + TABLE_USER;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // Move to first row
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            user.put("specialization", cursor.getString(1));
            user.put("email", cursor.getString(2));
            user.put("doctor", cursor.getString(3));
            user.put("date", cursor.getString(4));
            user.put("uid", cursor.getString(5));

        }
        cursor.close();
        db.close();
        // return user
        Log.d(TAG, "Fetching user from Sqlite: " + user.toString());

        return user;
    }

    /**
     * Re crate database Delete all tables and create them again
     * */
    public void deleteUsers() {
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete All Rows
        db.delete(TABLE_USER, null, null);
        db.close();

        Log.d(TAG, "Deleted all user info from sqlite");
    }

}

