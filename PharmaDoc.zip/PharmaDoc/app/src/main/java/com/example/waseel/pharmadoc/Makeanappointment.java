package com.example.waseel.pharmadoc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

//import com.example.waseel.pharmadoc.R;
import com.example.waseel.app.AppConfig;
import com.example.waseel.app.AppController;
import com.example.waseel.helper.SQhandler;
import com.example.waseel.helper.SessionManager;

public class Makeanappointment extends AppCompatActivity {
    private static final String TAG = Makeanappointment.class.getSimpleName();
    private EditText inputdoctorname;
    private EditText inputspec;
    private EditText location;
    private EditText inputdate;
    private EditText inputtime;
    private ProgressDialog pDialog;
    private SQhandler db;
    @SuppressLint("WrongViewCast")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_makeanappointment);

        inputdoctorname = findViewById(R.id.docname);
        inputspec = findViewById(R.id.specs);
        location = findViewById(R.id.location);
        inputdate = findViewById(R.id.date);
        inputtime = findViewById(R.id.time1);
        Button checkbtn = findViewById(R.id.button4);
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
// Session manager
        SessionManager session = new SessionManager(getApplicationContext());

        // SQLite database handler
        db = new SQhandler(getApplicationContext());
        if (session.isLoggedIn()) {
            // User is already logged in. Take him to main activity
            Intent intent = new Intent(Makeanappointment.this,
                    Makeanappointment.class);
            startActivity(intent);
            finish();
        }
checkbtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
     String doc_name = inputdoctorname.getText().toString().trim();
     String specs = inputspec.getText() .toString().trim();
     String loc = location.getText().toString().trim();
     String date = inputdate.getText().toString().trim();
     String time = inputtime.getText().toString().trim();
     if(!doc_name.isEmpty() && !specs.isEmpty() && !loc.isEmpty() && !date.isEmpty() && !time.isEmpty())
     {
         makeAppointment(doc_name,specs,loc,date,time);
         Intent intent = new Intent(getApplicationContext(),homepage.class);
         startActivity(intent);
         finish();
     }else {
         Toast.makeText(getApplicationContext(),
                 "Please enter the details!", Toast.LENGTH_LONG)
                 .show();
     }
    }
});


    }

    private void makeAppointment(final String doctor, final String specialization, final String location,  final String date, final String time){
        String tag_string_req = "req_register";

        pDialog.setMessage("Scheduling The Appointment ...");
        showDialog();
        StringRequest strReq = new StringRequest(Method.POST,
                AppConfig.URL_APPOINTMENT, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Scheduling Appointment: " + response);
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    if (!error) {
                        // User successfully stored in MySQL
                        // Now store the user in sqlite
                        String id = jObj.getString("id");

                        JSONObject user = jObj.getJSONObject("user");
                        String doctor = user.getString("doctor");
                        String specialization = user.getString("specialization");
                        String location = user.getString("location");
                        String date = user.getString("date");
                        String time = user.getString("time");
                        String phonenumber = user.getString("phone_number");
                        String email = user.getString("email");

                        // Inserting row in users table
                        db.addUser(doctor,specialization,location,date,time,email,phonenumber,id);

                        Toast.makeText(getApplicationContext(), "Appointment Scheduled!", Toast.LENGTH_LONG).show();

                        // Launch login activity
                        Intent intent = new Intent(
                                Makeanappointment.this,
                                homepage.class);
                        startActivity(intent);
                        finish();
                    } else {

                        // Error occurred in registration. Get the error
                        // message
                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(getApplicationContext(),
                                errorMsg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Appointment Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting params to register url
                Map<String, String> params = new HashMap<>();
                params.put("doctor", doctor);
                params.put("specialization", specialization);
                params.put("locaiton", location);
                params.put("date", date);
                params.put("time", time);






                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}
