package com.example.waseel.pharmadoc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class homepage extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        Button signup = findViewById(R.id.button7);
        Button aboutus = findViewById(R.id.button8);
        Button searchmeds = findViewById(R.id.button9);
        Button feedback = findViewById(R.id.button10);
        Button appointment = findViewById(R.id.button12);
        Button login = findViewById(R.id.button3);
signup.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        opensignup();
    }
});
aboutus.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        //openaboutus();
    }
});
searchmeds.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        opensearchmedicine();
    }
});
appointment.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        openappointment();
    }
});
login.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        openlogin();
    }
});
    }
    public void openappointment(){
        Intent intent = new Intent(this,Makeanappointment.class);
        startActivity(intent);
    }
public  void opensignup()
{
    Intent intent = new Intent(this,RegisterActivity.class);
    startActivity(intent);
}

   // public void openaboutus() {
     //   Intent intent = new Intent(this, com.example.waseel.pharmadoc.aboutus.class);
       // startActivity(intent);

    //}
    public void openlogin()
    {
        Intent intent = new Intent(this,LoginActivity.class);
        startActivity(intent);
    }


    public void opensearchmedicine() {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);

    }

}
