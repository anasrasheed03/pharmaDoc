package com.example.waseel.pharmadoc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class searchmedicine extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchmedicine);
    }
}
