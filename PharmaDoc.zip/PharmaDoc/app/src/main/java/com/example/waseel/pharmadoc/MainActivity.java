package com.example.waseel.pharmadoc;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import java.util.Scanner;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    TextView result;
    EditText med_name;
    Button search;
    String name;
    private ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        search = (Button)findViewById(R.id.button);
        result = (TextView)findViewById(R.id.textView);
        med_name = (EditText)findViewById(R.id.med_name);
        pd = new ProgressDialog(MainActivity.this);
        pd.setMessage("loading");
        pd.setCancelable(false);
        pd.setCanceledOnTouchOutside(false);



search.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

         name = med_name.getText().toString().trim();
         name = name.replaceAll(" ","%20");
         getSqlDetails();
    }
});


    }


    private void getSqlDetails() {

        String url= "http://haya.logicalhive.com/apis/med-search.php?stringRequest="+name;
        pd.show();
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                     pd.hide();


                        try {

                            JSONArray jsonarray = new JSONArray(response);

                            for(int i=0; i < jsonarray.length(); i++) {

                                JSONObject jsonobject = jsonarray.getJSONObject(i);


                                String id = jsonobject.getString("alt_med");
                                String price = jsonobject.getString("med_price").trim();
                                String name = jsonobject.getString("med_name").trim();
                                String phone = jsonobject.getString("med_generic").trim();
                                String alt_price = jsonobject.getString("alt_med_price").trim();
                                result.setText("Medicine Name -"+name+"\n Price -"+price+"\n Generic -"+phone+"\n Alternate Medicine Name -"+id+"\n Alternate Medicine Price - "+alt_price);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();


                        }




                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if(error != null){

                            Toast.makeText(getApplicationContext(), "Something went wrong.", Toast.LENGTH_LONG).show();
                        }
                    }
                }

        );

        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }





}
