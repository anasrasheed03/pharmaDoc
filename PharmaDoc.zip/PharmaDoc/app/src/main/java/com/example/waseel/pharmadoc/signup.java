package com.example.waseel.pharmadoc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class signup extends AppCompatActivity {
private EditText fname,uname,email,pass,cpass,pnumber,dob;
private Button signup;

@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
     signup= findViewById(R.id.button6);
     signup.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             openmainactivity();
         }
     });
        fname = (EditText) findViewById(R.id.editText3);
     uname =  (EditText) findViewById(R.id.editText4);
     email = (EditText) findViewById(R.id.editText5);
     pass = (EditText) findViewById(R.id.editText6);
     cpass = (EditText) findViewById(R.id.editText7);
     pnumber = (EditText) findViewById(R.id.editText8);
     dob = (EditText) findViewById(R.id.editText9);

    }
    public void openmainactivity(){
        Intent intent = new Intent(this,homepage.class);
        startActivity(intent);
}
    public  void  signuppost(View view)
    {
        String fullname = fname.getText().toString();
        String username = uname.getText().toString();
        String emails = email.getText().toString();
        String password = pass.getText().toString();
        String confirm = cpass.getText().toString();
        String date = dob.getText().toString();
        }
}
