package com.example.waseel.app;

public class AppConfig {
	// Server user login url
	public static String URL_LOGIN = "http://haya.logicalhive.com/apis/login.php";
    public static String URL_REGISTER="http://haya.logicalhive.com/apis/registration.php";
    public  static String  URL_APPOINTMENT="http://haya.logicalhive.com/apis/appointment.php";
	// Server user register url
	//public static String URL_REGISTER = "http://192.168.0.102/android_login_api/register.php";
}
