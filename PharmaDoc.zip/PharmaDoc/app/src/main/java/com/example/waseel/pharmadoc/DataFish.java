package com.example.waseel.pharmadoc;

public class DataFish {
    public String fishName;
    public String catName;
    public String sizeName;
    public int price;
}
